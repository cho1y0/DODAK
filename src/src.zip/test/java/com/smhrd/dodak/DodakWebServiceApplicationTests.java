package com.smhrd.dodak;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DodakWebServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
